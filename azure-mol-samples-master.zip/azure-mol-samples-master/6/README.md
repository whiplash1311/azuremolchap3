Very basic Azure Resource Manager template that deploys the same VM as created in chapter 2. This example shows how the different Resource Manager components are pieced together to build a VM. You are prompted for the SSH public key, and that's it. This approach makes it quick to deploy VMs in a clean, consistent manner. More values can be changed to parameters that you are prompted for as you deploy.

<a href="https://portal.azure.com/#create/Microsoft.Template/uri/https%3A%2F%2Fraw.githubusercontent.com%2Ffouldsy%2Fazure-samples%2Fmaster%2F7%2Fwebvm-template.json" target="_blank">
    <img src="http://azuredeploy.net/deploybutton.png"/>
</a>
<a href="http://armviz.io/#/?load=https%3A%2F%2Fraw.githubusercontent.com%2Ffouldsy%2Fazure-samples%2Fmaster%2F7%2Fwebvm-template.json" target="_blank">
    <img src="http://armviz.io/visualizebutton.png"/>
</a>