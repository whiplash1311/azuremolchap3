var config = {}

config.uri = "";
config.primaryKey = "";
config.database = { "id": "pizzadb" };
config.collection = { "id": "pizzas" };

module.exports = config;
